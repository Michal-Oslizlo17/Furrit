<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posts</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <style>
        .blur {
            filter: blur(8px);
            background-color: rgba(255, 255, 255, 0.8);
        }

        .post {
            margin-bottom: 20px;
        }

        .nsfw-badge {
            display: inline-block;
            margin-left: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-4"></div>
        <div class="row">
            <?php
            // Database configuration
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "furrit";

            // Create a new database connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check the database connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Initialize the $result variable
            $result = false;

            if (isset($_GET['post_id'])) {
                // Get post ID from the URL
                $post_id = $_GET['post_id'];

                // Prepare and execute a safe SQL query using a parameterized statement
                $sql = "SELECT ID, Title, Content, Author, Data, NSFW, Category, Likes, Dislikes FROM posts WHERE id = ?";
                if ($stmt = $conn->prepare($sql)) {
                    $stmt->bind_param("i", $post_id); // "i" indicates an integer parameter
                    $stmt->execute();
                    $result = $stmt->get_result();
                }
            } else {
                // Prepare and execute a query to retrieve all posts
                $sql = "SELECT ID, Title, Content, Author, Data, NSFW, Category, Likes, Dislikes FROM posts";
                $result = $conn->query($sql);
            }

            if ($result === false) {
                // Handle SQL query errors
                die("Error in SQL query: " . $conn->error);
            }

            // Check if any posts were found
            try {
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-6">';
                        echo '<div class="post card mb-4">';
                        if ($row["NSFW"] == 1) {
                            echo '<button class="btn btn-secondary" data-id="' . $row["ID"] . '">Show mature content</button>';
                        }
                        echo '<div class="card-body' . ($row["NSFW"] == 1 ? ' blur' : '') . '">';
                        echo '<h5 class="card-title">' . $row["Title"] . '</h5>';
                        echo '<p class="card-text">' . $row["Content"] . '</p>';
                        echo '<p class="card-text"><small class="text-muted">Author: ' . $row["Author"] . '</small></p>';
                        echo '<p class="card-text"><small class="text-muted">Date: ' . $row["Data"] . '</small></p>';
                        echo '<p class="card-text"><small class="text-muted">Category: ' . $row["Category"] . '</small></p>';
                        if ($row["NSFW"] == 1) {
                            echo '<span class="badge bg-danger nsfw-badge">NSFW</span>';
                        }
                        echo '<button class="btn btn-primary like" data-id="' . $row["ID"] . '">Like (' . $row["Likes"] . ')</button>';
            
                        if (!isset($_GET['post_id'])) {
                            echo '<a href="?post_id=' . $row["ID"] . '" class="btn btn-info">Show Post</a>';
                        }
            
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="col-md-12">';
                    echo '<div class="alert alert-info">No posts found.</div>';
                    echo '</div>';
                }
            }
            catch (\Throwable $th) {
                echo $th;
            }

            // Close the database connection
            $conn->close();
            ?>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('click', function(e) {
            if (e.target && e.target.tagName == 'BUTTON') {
                var postId = e.target.getAttribute('data-id');

                if (e.target.textContent == 'Show mature content') {
                    e.target.textContent = '';
                    e.target.style = true; // Dezaktywuj przycisk
                    e.target.style.backgroundColor = 'transparent'; // Zmień tło przycisku na szare
                    e.target.style.color = 'white'; // Zmień kolor tekstu na ciemnoszary
                    e.target.style.border = '0px';
                    e.target.parentElement.querySelector('.blur').classList.remove('blur');
                } else if (e.target.classList.contains('like') || e.target.classList.contains('dislike')) {
                    // Handle liking/disliking logic here
                    var action = e.target.classList.contains('like') ? 'like' : 'dislike';

                    fetch('../modules/score_counter.php', {
                            method: 'POST',
                            body: JSON.stringify({
                                post_id: postId,
                                action: action
                            }),
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            // Update the like/dislike count in the button text
                            e.target.textContent = action == 'like' ? 'Like (' + data.likes + ')' : 'Dislike (' + data.dislikes + ')';
                        });
                }
            }
        });
    </script>
</body>

</html>