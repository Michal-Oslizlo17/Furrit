<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <meta http-equiv="refresh" content="0.5; url=forum/index.php">
</head>
<body>
  <style>
    #text {
      font-size: 100px;
      color: red;
      text-align: center;
      width: 100%;
      height: 100vh;
      font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
      text-align: center;
      margin-top: 40vh;
    }
  </style>
  <div id="text"><text>Redirecting...</text></div>
</body>
</html>