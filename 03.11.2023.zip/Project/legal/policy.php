<!DOCTYPE html>
<html lang="en" class="h-100" data-bs-theme="auto">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <meta name="generator" content="">
  <title>Your Site</title>
  <!-- Favicon-->
  <link rel="icon" type="image/x-icon" href="src/favicon/favicon.ico" />
  <!-- Bootstrap icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
  <!-- Core theme CSS (includes Bootstrap)-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../homepage_style.css" rel="stylesheet" />
  <link rel="stylesheet" href="../cursor.css">
  <link rel="stylesheet" href="../style.css">
  <link rel="stylesheet" href="../config.css">
</head>

<body>
  <!-- Responsive navbar-->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../src/favicon/Furrit_Paw_Text.png" alt="Logo" width="100" height="30" class="d-inline-block align-text-top">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="homepage.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../legal/rules.php">Rules</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Account
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" id="account" href="../legal/#">Account Settings</a></li>
              <li><a class="dropdown-item" id="account" href="../legal/#">Account Information</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" id="account" href="../legal/searchforaccount.php">Find Someone.</a></li>
              <li><a class="dropdown-item" id="account" href="../legal/policy.php">Privacy Policy</a></li>
              <li><a class="dropdown-item" id="account" href="../legal/#">Account Deactivation</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled">Disabled</a>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
        <li class="nav-link" style="margin-left: 10px;">
        <?php
          if (isset($_SESSION['email'])) {
            $username = $_SESSION['username'];
            $email = $_SESSION['email'];

            $maxUsernameLength = 255;
            $maxEmailLength = 255;

            if (strlen($username) > $maxUsernameLength) {
              $username = substr($username, 0, $maxUsernameLength) . "...";
            }

            if (strlen($email) > $maxEmailLength) {
              $email = substr($email, 0, $maxEmailLength) . "...";
            }

            echo '<a style="margin-right: 10px;">Zalogowany użytkownik: <b style="color: var(--navy);">' . $username . '</span></b></a>';
            echo '<a href="../logout.php"><button class="btn btn-outline-primary">Wyloguj się</button></a>';
          } else {
            echo '<a href="../login.php"><button class="btn btn-outline-primary">Zaloguj się</button></a>';
            echo '<script>// Pobierz wszystkie elementy o identyfikatorze "account".
                var accountElements = document.querySelectorAll("#account");

                // Iteruj przez znalezione elementy i dodaj klasę "disabled" do każdego z nich.
                accountElements.forEach(function (element) {
                  element.classList.add("disabled");
                  element.textContent
                });
              </script>';
          }
          ?>
        </li>

      </div>
    </div>
  </nav>
  <!-- Navbar -->
  <!-- Header-->
  <header class="py-5">
    <div class="container px-lg-5">
      <div class="p-4 p-lg-5 bg-light rounded-3 text-center">
        <div class="m-4 m-lg-5"style="text-align:left;">
          <h1 class="display-5 fw-bold">Safety Policy</h1>
          <p class="fs-4">
          <ol>

          <h2>Purpose and assumptions</h2>
    <ol>
        <li><strong>Rule of Respecting Others: </strong> Furrit is a place where users with different beliefs and political beliefs can interact with each other. All users are obliged to respect other participants and their opinions. Offensive, discriminatory, or insulting content is not acceptable.</li>
        <li><strong>Users Safety:</strong> Furrit is committed to providing a safe and friendly environment. It is unacceptable to share personal information or put other users at risk</li>
        <li><strong>Anti-Harassment and Anti-Violence:</strong>  Furrit does not tolerate harassment, cyberbullying or incitement to violence in any form. Such behavior will be prosecuted in accordance with applicable laws.</li>
    </ol>

    <h2>Moderation and reporting</h2>
    <ol>
        <li><strong>Community Moderation:</strong> Moderators are responsible for maintaining compliance with the Safety Policy. They have the right to remove content and implement sanctions in case of violations.</li>
        <li><strong>Violations Reporting:</strong> Users are encouraged to actively report violations of the Security Policy through the tools available on the platform. Every report is treated seriously.</li>
    </ol>

    <h2>Forbidden content</h2>
    <ol>
        <li><strong>Offensive and Discriminatory Content:</strong> Offensive, racist, sexist, homophobic or other content that promotes hatred or discrimination is prohibited.</li>
        <li><strong>Harassment and Violence:</strong> Harassing other users, inciting violence, or spreading violent content is strictly prohibited.</li>
        <li><strong>Nudity and Mature Content:</strong> Mature content should be marked as such and posted in the appropriate subfurrits. It is unacceptable to publish pornography, pedophilia or other illegal content.</li>
        <li><strong>False Information:</strong> Furrit strives to reduce the spread of false information. Spreading misinformation or promoting conspiracy theories may result in your content or account being deleted.</li>
    </ol>

    <h2>Sanctions for Violations</h2>
    <ol>
        <li><strong>Sanctions For Users:</strong> Violations of the Security Policy may lead to various sanctions, such as warnings, account suspensions, or permanent deletion, depending on the severity of the violation.</li>
        <li><strong>Sanctions for Moderators:</strong> Moderators who abuse their role or do not comply with the Security Policy may be deprived of moderation rights.</li>
    </ol>

    <p>Furrit reserves the right to change the Security Policy at any time to adapt it to changing community needs and legal regulations.</p>

    <p>his Security Policy aims to maintain Furrit as a place for open dialogue and the exchange of ideas, while ensuring the safety and comfort of all users. Users are obliged to comply with these rules when using the platform.</p>

          </p>
        </div>
      </div>
    </div>
  </header>
  <!-- Page World -->
  <style>
    .no-padding {
      padding: 0;
    }
  </style>
  <!-- Footer-->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; </p>
    </div>
  </footer>
  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="homepage_script.js"></script>
</body>

</html>