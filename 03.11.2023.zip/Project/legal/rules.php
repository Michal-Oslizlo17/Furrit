<!DOCTYPE html>
<html lang="en" class="h-100" data-bs-theme="auto">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <meta name="generator" content="">
  <title>Your Site</title>
  <!-- Favicon-->
  <link rel="icon" type="image/x-icon" href="../assets/src/favicon/favicon.ico" />
  <!-- Bootstrap icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
  <!-- Core theme CSS (includes Bootstrap)-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="homepage_style.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/cursor.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/config.css">
</head>

<body>
  <!-- Responsive navbar-->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../assets/src/favicon/Furrit_Paw_Text.png" alt="Logo" width="100" height="30" class="d-inline-block align-text-top">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="../homepage.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../legal/rules.php">Rules</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Account
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" id="account" href="../legal/#">Account Settings</a></li>
              <li><a class="dropdown-item" id="account" href="../legal/#">Account Information</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" id="account" href="../legal/searchforaccount.php">Find Someone.</a></li>
              <li><a class="dropdown-item" id="account" href="../legal/policy.php">Privacy Policy</a></li>
              <li><a class="dropdown-item" id="account" href="../legal/#">Account Deactivation</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled">Disabled</a>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
        <li class="nav-link" style="margin-left: 10px;">
          <?php
          if (isset($_SESSION['email'])) {
            $username = $_SESSION['username'];
            $email = $_SESSION['email'];

            $maxUsernameLength = 255;
            $maxEmailLength = 255;

            if (strlen($username) > $maxUsernameLength) {
              $username = substr($username, 0, $maxUsernameLength) . "...";
            }

            if (strlen($email) > $maxEmailLength) {
              $email = substr($email, 0, $maxEmailLength) . "...";
            }

            echo '<a style="margin-right: 10px;">Zalogowany użytkownik: <b style="color: var(--navy);">' . $username . '</span></b></a>';
            echo '<a href="logout.php"><button class="btn btn-outline-primary">Wyloguj się</button></a>';
          } else {
            echo '<a href="login.php"><button class="btn btn-outline-primary">Zaloguj się</button></a>';
            echo '<script>// Pobierz wszystkie elementy o identyfikatorze "account".
                var accountElements = document.querySelectorAll("#account");

                // Iteruj przez znalezione elementy i dodaj klasę "disabled" do każdego z nich.
                accountElements.forEach(function (element) {
                  element.classList.add("disabled");
                  element.textContent
                });
              </script>';
          }
          ?>
        </li>

      </div>
    </div>
  </nav>
  <!-- Navbar -->
  <!-- Header-->
  <header class="py-5">
    <div class="container px-lg-5">
      <div class="p-4 p-lg-5 bg-light rounded-3 text-center">
        <div class="m-4 m-lg-5" style="text-align: left;">
          <h1 class="display-5 fw-bold">Rules of using Furrit platform.</h1>
          <p class="fs-4">
          <ol>
            <h3>
              <li>Respect other users</li>
            </h3>
            <ul>
              <li>Avoid offensive, racist, sexist, and aggressive behavior.</li>
              <li>Respect diversity and different viewpoints.</li>
            </ul>

            <h3>
              <li>Don't spam</li>
            </h3>
            <ul>
              <li>Don't post repetitive content.</li>
              <li>Don't overly promote your product or service.</li>
            </ul>

            <h3>
              <li>Protect privacy</li>
            </h3>
            <ul>
              <li>Don't publish the private information of other users without their consent.</li>
              <li>Respect the privacy of others.</li>
              <li>Don't disclose private information to third parties; it may reach unauthorized individuals.</li>
            </ul>

            <h3>
              <li>Do not share illegal content</li>
            </h3>
            <ul>
              <li>Avoid posting copyrighted materials.</li>
              <li>Do not post pornographic content, illegal substances, threats, or behaviors that endanger safety.</li>
            </ul>

            <h3>
              <li>Tag content appropriately</li>
            </h3>
            <ul>
              <li>Add suitable categories and tags to your posts to help other users find content of their interest.</li>
            </ul>

            <h3>
              <li>Behave respectfully</li>
            </h3>
            <ul>
              <li>Ensure that your comments and posts are clear and courteous.</li>
              <li>Avoid excessive use of profanity.</li>
            </ul>

            <h3>
              <li>Be constructive</li>
            </h3>
            <ul>
              <li>Strive to add value to discussions by offering substantive comments and opinions.</li>
            </ul>

            <h3>
              <li>Do not violate the rules set by specific subreddits</li>
            </h3>
            <ul>
              <li>Each subreddit may have its own rules and guidelines that must be followed.</li>
            </ul>

            <h3>
              <li>Avoid unnecessary conflict</li>
            </h3>
            <ul>
              <li>Avoid aggressively attacking other users and attempting to provoke conflicts.</li>
            </ul>

            <h3>
              <li>Be authentic</li>
            </h3>
            <ul>
              <li>Do not misrepresent your identity or deliberately spread disinformation.</li>
            </ul>

            <h3>
              <li>Report inappropriate behavior</li>
            </h3>
            <ul>
              <li>If you come across content that violates the rules, report it to the platform's moderators or administrators.</li>
            </ul>
          </ol>
          Non-compliance with these rules may lead to warnings, suspensions, or bans on the Reddit platform, depending on the severity of the violation. Therefore, it is important to use Reddit with respect for other users and in accordance with the established guidelines.<br>
          <a class="btn btn-primary btn-lg" href="policy.php">Safety Policy</a>
        </div>
      </div>
    </div>
  </header>
  <!-- Page World -->
  <style>
    .no-padding {
      padding: 0;
    }
  </style>
  <!-- Footer-->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; </p>
    </div>
  </footer>
  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="homepage_script.js"></script>
</body>

</html>