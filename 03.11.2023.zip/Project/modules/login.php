<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Your Site</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="../assets/src/favicon/favicon.ico" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="../assets/css/homepage_style.css">
    <link rel="stylesheet" href="../assets/css/cursor.css">
    <link rel="stylesheet" href="../assets/css/login_style.css">
    <link rel="stylesheet" href="../assets/css/config.css">
</head>

<body>
    <div class="login-dark">
        <form method="post" action="checklogin.php">
            <!-- Dodaj miejsce na wyświetlanie komunikatu błędu -->
            <div id="error-message" style="color: aqua; text-align: center; margin-bottom: 20px;"></div>
            <script>
                // Odczytaj parametry z adresu URL
                const urlParams = new URLSearchParams(window.location.search);
                const error = urlParams.get('error');

                // Wyświetl odpowiedni komunikat w zależności od parametru 'error'
                if (error === 'success') {
                    document.getElementById('error-message').innerText = 'Registration was succesful.';
                } else if (error === 'registration_failed') {
                    document.getElementById('error-message').innerText = 'There was an error during registration.';
                } else if (error === 'invaliddata') {
                    document.getElementById('error-message').innerText = 'Incorrect login info.';
                } else if (error === 'noexist') {
                    document.getElementById('error-message').innerText = 'Username doesn\'t exist.';
                } else if (error === 'logout') {
                    document.getElementById('error-message').innerText = 'Logged out succesfully.';
                }
            </script>
            <h2 class="sr-only sr-only-focusable text-center" style="margin-bottom: 20px;">Login</h2>
            <div class="form-group">
                <input class="form-control" type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input class="form-control" type="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group text-center">
                <button class="btn btn-primary btn-block" type="submit">Log In</button>
            </div>
            <div class="form-group" style="margin-top: 10px;">
                <a href="#" class="forgot">Forgot your email or password?</a>
            </div>
            <div class="form-group" style="font-size: 12px;">
                <a href="register.php" class="register">Don't have an account?</a>
            </div>
        </form>
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>