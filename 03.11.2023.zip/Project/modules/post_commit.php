<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    // Połączenie z bazą danych (zmień dane na odpowiednie dla Twojej konfiguracji)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "furrit";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdź, czy udało się połączyć z bazą danych
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Pobierz dane z formularza
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_POST['author'];
    $category = $_POST['category'];
    $nsfw = isset($_POST['nsfw']) ? 1 : 0;

    // Wstaw dane do bazy danych (tabela i kolumny muszą być dostosowane do Twojej konfiguracji)
    $sql = "INSERT INTO posts (Title, Content, Author, Category, NSFW, Likes, DisLikes) VALUES ('$title', '$content', '$author', '$category', $nsfw, 0, 0)";

    if ($conn->query($sql) === TRUE) {
        echo "New entry added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Zakończ połączenie z bazą danych
    $conn->close();
    ?>
</body>

</html>