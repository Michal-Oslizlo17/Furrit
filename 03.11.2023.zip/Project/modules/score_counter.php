<?php
// Połączenie z bazą danych (zmień dane na odpowiednie dla Twojej konfiguracji)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "furrit";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Odbierz dane z żądania POST
$data = json_decode(file_get_contents("php://input"));

if ($data && isset($data->post_id) && isset($data->action)) {
    $post_id = $data->post_id;
    $action = $data->action;

    // Sprawdź, czy akcja to "like" lub "dislike"
    if ($action == "like" || $action == "dislike") {
        session_start();
        if (isset($_SESSION['email'])) {
            $email = $_SESSION['email'];
            
            // Sprawdź, czy użytkownik już głosował na ten post
            $checkVoteQuery = "SELECT * FROM user_votes WHERE user_email = '$email' AND post_id = $post_id";
            $result = $conn->query($checkVoteQuery);
            
            if ($result->num_rows == 0) {
                // Użytkownik jeszcze nie głosował na ten post, zezwól na głosowanie
                $sql = "UPDATE posts SET ";
                if ($action == "like") {
                    $sql .= "likes = likes + 1 ";
                } else {
                    $sql .= "dislikes = dislikes + 1 ";
                }
                $sql .= "WHERE id = $post_id";

                if ($conn->query($sql) === TRUE) {
                    // Dodaj wpis o głosie użytkownika do tabeli user_votes
                    $insertVoteQuery = "INSERT INTO user_votes (user_email, post_id, action) VALUES ('$email', $post_id, '$action')";
                    $conn->query($insertVoteQuery);

                    // Pobierz zaktualizowane wartości like i dislike z bazy danych
                    $sql = "SELECT likes, dislikes FROM posts WHERE id = $post_id";
                    $result = $conn->query($sql);

                    if ($result->num_rows == 1) {
                        $row = $result->fetch_assoc();

                        // Przygotuj odpowiedź JSON z zaktualizowanymi wartościami
                        $response = [
                            "likes" => $row["likes"],
                            "dislikes" => $row["dislikes"]
                        ];

                        header('Content-Type: application/json');
                        echo json_encode($response);
                    }
                } else {
                    echo "Error updating record: " . $conn->error;
                }
            } else {
                // Jeśli użytkownik wcześniej zagłosował, to sprawdź, czy próbuje cofnąć głos
                $row = $result->fetch_assoc();
                $previousAction = $row["action"];
                
                if ($previousAction == $action) {
                    // Użytkownik próbuje ponownie oddać ten sam głos, nie rób nic
                    echo "You have already voted for this post.";
                } else {
                    // Użytkownik próbuje zmienić swój głos, zaktualizuj bazę danych
                    $sql = "UPDATE posts SET ";
                    if ($action == "like") {
                        $sql .= "likes = likes + 1, dislikes = dislikes - 1 ";
                    } else {
                        $sql .= "likes = likes - 1, dislikes = dislikes + 1 ";
                    }
                    $sql .= "WHERE id = $post_id";
                    
                    if ($conn->query($sql) === TRUE) {
                        // Zaktualizuj wpis w tabeli user_votes
                        $updateVoteQuery = "UPDATE user_votes SET action = '$action' WHERE user_email = '$email' AND post_id = $post_id";
                        $conn->query($updateVoteQuery);

                        // Pobierz zaktualizowane wartości like i dislike z bazy danych
                        $sql = "SELECT likes, dislikes FROM posts WHERE id = $post_id";
                        $result = $conn->query($sql);

                        if ($result->num_rows == 1) {
                            $row = $result->fetch_assoc();

                            // Przygotuj odpowiedź JSON z zaktualizowanymi wartościami
                            $response = [
                                "likes" => $row["likes"],
                                "dislikes" => $row["dislikes"]
                            ];

                            header('Content-Type: application/json');
                            echo json_encode($response);
                        }
                    } else {
                        echo "Error updating record: " . $conn->error;
                    }
                }
            }
        } else {
            echo "User not logged in.";
        }
    } else {
        echo "Invalid action.";
    }
} else {
    echo "Invalid data.";
}

$conn->close();
?>
