<!DOCTYPE html>
<html lang="en" class="h-100" data-bs-theme="auto">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <meta name="generator" content="">
  <title>Your Site</title>
  <!-- Favicon-->
  <link rel="icon" type="image/x-icon" href="src/favicon/favicon.ico" />
  <!-- Bootstrap icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
  <!-- Core theme CSS (includes Bootstrap)-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="homepage_style.css" rel="stylesheet" />
  <link rel="stylesheet" href="cursor.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="config.css">
</head>

<body>
  <!-- Responsive navbar-->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="src/favicon/Furrit_Paw_Text.png" alt="Logo" width="100" height="30" class="d-inline-block align-text-top">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="homepage.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="rules.php">Rules</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Account
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" id="account" href="./aboutus/accountsettings.php">Ustawienia konta</a></li>
              <li><a class="dropdown-item" id="account" href="./aboutus/accountdata.php">Dane konta</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" id="account" href="./aboutus/searchforaccount.php">Wyszukaj konto</a></li>
              <li><a class="dropdown-item" id="account" href="./aboutus/policy.php">Polityka bezpieczeństwa</a></li>
              <li><a class="dropdown-item" id="account" href="./aboutus/deactivation.php">Deaktywacja</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled">Disabled</a>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
        <li class="nav-link" style="margin-left: 10px;">
          <?php
          session_start();

          if (isset($_SESSION['email'])) {
            $username = $_SESSION['username'];
            $email = $_SESSION['email'];

            $maxUsernameLength = 255;
            $maxEmailLength = 255;

            if (strlen($username) > $maxUsernameLength) {
              $username = substr($username, 0, $maxUsernameLength) . "...";
            }

            if (strlen($email) > $maxEmailLength) {
              $email = substr($email, 0, $maxEmailLength) . "...";
            }

            echo '<a style="margin-right: 10px;">Zalogowany użytkownik: <b style="color: var(--navy);">' . $username . '</span></b></a>';
            echo '<a id="logout" href="logout.php">Wyloguj się</a>';
          } else {
            echo '<a id="login" href="login.php">Zaloguj się</a>';
            echo '<script>// Pobierz wszystkie elementy o identyfikatorze "account".
            var accountElements = document.querySelectorAll("#account");
            
            // Iteruj przez znalezione elementy i dodaj klasę "disabled" do każdego z nich.
            accountElements.forEach(function(element) {
                element.classList.add("disabled");
                element.textContent
            });
            </script>';
          }
          ?>
        </li>

      </div>
    </div>
  </nav>
  <!-- Navbar -->
  <!-- Header-->
  <header class="py-5">
    <div class="container px-lg-5">
      <div class="p-4 p-lg-5 bg-light rounded-3 text-center">
        <div class="m-4 m-lg-5">
          <h1 class="display-5 fw-bold">Zasady korzystania z platformy Furrit</h1>
          <p class="fs-4">
          <ol>

          <h3><li>Szanuj innych użytkowników</li></h3>
            <ul>
              <li>Unikaj obraźliwego, rasistycznego, seksistowskiego i agresywnego zachowania.</li>
              <li>Szanuj różnorodność i punkty widzenia innych.</li>
            </ul>

            <h3><li>Nie spamuj</li></h3>
            <ul>
              <li>Nie zamieszczaj powtarzających się treści.</li>
              <li>Nie promuj swojego produktu lub usługi w sposób nachalny.</li>
            </ul>

            <h3><li>Zachowuj prywatność</li></h3>
            <ul>
              <li>Nie publikuj prywatnych informacji innych użytkowników bez ich zgody.</li>
              <li>Szanuj prywatność innych.</li>
              <li>Nie podawaj prywatnych danych osobą postronnym. Mogą te danę dojść do osób trzecich.</li>
            </ul>

            <h3><li>Nie udostępniaj nielegalnych treści</li></h3>
            <ul>
              <li>Unikaj publikowania materiałów chronionych prawem autorskim.</li>
              <li>Nie zamieszczaj treści pornograficznych, nielegalnych substancji, groźb lub zachowań zagrażających bezpieczeństwu.</li>
            </ul>

            <h3><li>Oznaczaj treści odpowiednimi tagami</li></h3>
            <ul>
              <li>Dodawaj odpowiednie kategorie i tagi do swoich postów, aby pomóc innym użytkownikom znaleźć interesujące ich treści.</li>
            </ul>

            <h3><li>Zachowuj się kulturalnie</li></h3>
            <ul>
              <li>Upewnij się, że Twoje komentarze i posty są zrozumiałe i kulturalne.</li>
              <li>Unikaj nadmiernej liczby przekleństw.</li>
            </ul>

            <h3><li>Bądź konstruktywny</li></h3>
            <ul>
              <li>Staraj się dodać wartość do dyskusji, oferując merytoryczne komentarze i opinie.</li>
            </ul>

            <h3><li>Nie łam zasad określonych przez konkretne subfurrit'y</li></h3>
            <ul>
              <li>Każdy subfurrit może mieć własne zasady i wytyczne, których należy przestrzegać.</li>
            </ul>

            <h3><li>Nie wywołuj zbędnego konfliktu</li></h3>
            <ul>
              <li>Unikaj agresywnego atakowania innych użytkowników i prób prowokacji.</li>
            </ul>

            <h3><li>Bądź autentyczny</li></h3>
            <ul>
              <li>Nie zakłamuj swojej tożsamości ani celowo nie rozpowszechniaj dezinformacji.</li>
            </ul>

            <h3><li>Zgłaszaj nieodpowiednie zachowania</li></h3>
            <ul>
              <li>Jeśli znajdziesz treści naruszające zasady, zgłoś je moderatorom lub administratorom platformy.</li>
            </ul>
          </ol>
          Nieprzestrzeganie tych zasad może prowadzić do ostrzeżeń, zawieszeń lub banów na platformie Reddit, 
          w zależności od ciężkości naruszenia. Dlatego ważne jest, aby korzystać z Reddit z poszanowaniem 
          dla innych użytkowników i zgodnie z ustalonymi wytycznymi.
          </p>
          <a class="btn btn-primary btn-lg" href="./aboutus/policy.php">Polityka Bezpieczeństwa</a>
        </div>
      </div>
    </div>
  </header>
  <!-- Page World -->
  <style>
    .no-padding {
      padding: 0;
    }
  </style>
  <!-- Footer-->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; </p>
    </div>
  </footer>
  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="homepage_script.js"></script>
</body>

</html>